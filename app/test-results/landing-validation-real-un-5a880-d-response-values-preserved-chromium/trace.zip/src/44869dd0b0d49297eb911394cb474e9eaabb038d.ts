import { expect, test, type Page } from "@playwright/test";

async function chooseLocale(page: Page, locale: string) {
  await page.locator("#language").selectOption(locale);
  await expect(page.locator("html")).toHaveAttribute("lang", locale);
}

async function assertLayout(page: Page) {
  const issues = await page.evaluate(() => {
    const viewport = document.documentElement.clientWidth;
    const errors: string[] = [];
    if (document.documentElement.scrollWidth > viewport + 1) errors.push(`Page overflow: ${document.documentElement.scrollWidth}/${viewport}`);
    document.querySelectorAll<HTMLElement>("h1, h2, h3, figcaption, form input:not([type=checkbox]), form textarea, form select").forEach(element => {
      const rect = element.getBoundingClientRect();
      if (rect.width && (rect.left < -1 || rect.right > viewport + 1)) errors.push(`${element.tagName}: ${element.textContent?.slice(0, 60)} is out of bounds (${rect.left}, ${rect.right})`);
    });
    return errors;
  });
  expect(issues).toEqual([]);
}

for (const width of [320, 375, 430, 768, 1024, 1440]) {
  for (const locale of ["es", "en", "fr"]) {
    test(`responsive ${width}px ${locale}: home and contact`, async ({ page }) => {
      await page.setViewportSize({ width, height: 900 });
      await page.emulateMedia({ reducedMotion: "reduce" });
      const errors: string[] = [];
      page.on("pageerror", error => errors.push(error.message));
      page.on("console", message => { if (message.type() === "error") errors.push(message.text()); });
      await page.goto("/#/");
      await chooseLocale(page, locale);
      await expect(page.locator("h1")).toHaveCount(1);
      await expect(page.locator("main form")).toHaveCount(0);
      await expect(page.locator("main section")).toHaveCount(7);
      await assertLayout(page);
      const hero = page.locator("h1");
      const figure = page.locator("#top figure");
      const a = await hero.boundingBox();
      const b = await figure.boundingBox();
      expect(a && b && a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y).toBe(false);
      await page.goto("/#/contacto");
      await expect(page.locator("html")).toHaveAttribute("lang", locale);
      await expect(page.locator("h1")).toHaveCount(1);
      await expect(page.locator("form")).toBeVisible();
      await expect(page.locator("#f-consent")).not.toBeChecked();
      await assertLayout(page);
      expect(errors).toEqual([]);
    });
  }
}

test("contact navigation, preselection and cross-page anchors", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/#/");
  await page.locator('a[href="#/contacto?need=software"]').click();
  await expect(page).toHaveURL(/#\/contacto\?need=software/);
  await expect(page.locator("#f-tipo")).toHaveValue("software");
  await page.locator('footer a[href="#/?section=metodo"]').click();
  await expect(page).toHaveURL(/section=metodo/);
  await expect(page.locator("#metodo")).toBeFocused();
  const top = await page.locator("#metodo").evaluate(element => element.getBoundingClientRect().top);
  expect(top).toBeGreaterThanOrEqual(63);
  expect(top).toBeLessThan(100);
});

test("validation, real unconfigured backend response, values preserved", async ({ page }) => {
  await page.goto("/#/contacto");
  await page.getByRole("button", { name: "Enviar mi consulta ↗" }).click();
  await expect(page.locator("#f-nombre")).toBeFocused();
  await expect(page.locator("#error-email")).toBeVisible();
  await page.locator("#f-nombre").fill("Prueba local");
  await page.locator("#f-email").fill("invalid");
  await page.locator("#f-mensaje").fill("Necesitamos simplificar un proceso manual.");
  await page.locator("#f-consent").check();
  await page.getByRole("button", { name: "Enviar mi consulta ↗" }).click();
  await expect(page.locator("#error-email")).toContainText("Ese correo no parece válido");
  await page.locator("#f-email").fill("test@example.com");
  await page.waitForTimeout(2100);
  const response = page.waitForResponse(response => response.url().includes("/api/trpc/contact.submit"));
  await page.getByRole("button", { name: "Enviar mi consulta ↗" }).click();
  expect((await response).status()).toBe(503);
  await expect(page.getByRole("alert")).toContainText("no está configurado");
  await expect(page.locator("#f-nombre")).toHaveValue("Prueba local");
  await expect(page.getByText("Recibido.", { exact: true })).toHaveCount(0);
});

test("confirmed success and duplicate submit guard (mocked provider response)", async ({ page }) => {
  let requests = 0;
  await page.route("**/api/trpc/contact.submit*", async route => {
    requests++;
    await new Promise(resolve => setTimeout(resolve, 300));
    await route.fulfill({ json: [{ result: { data: { json: { ok: true, forwarded: true } } } }] });
  });
  await page.goto("/#/contacto");
  await page.locator("#f-nombre").fill("Prueba simulada");
  await page.locator("#f-email").fill("test@example.com");
  await page.locator("#f-mensaje").fill("Esta prueba no envía ningún correo real.");
  await page.locator("#f-consent").check();
  await page.locator("form").evaluate(form => { form.requestSubmit(); form.requestSubmit(); });
  await expect(page.getByRole("status")).toContainText("Recibido.");
  expect(requests).toBe(1);
});

test("mobile menu keyboard trap, Escape, and translated privacy", async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 812 });
  await page.goto("/#/");
  await chooseLocale(page, "fr");
  const open = page.getByRole("button", { name: "Ouvrir le menu" });
  await open.click();
  await expect(page.locator("#menu-movil a").first()).toBeFocused();
  for (let i = 0; i < 8; i++) {
    await page.keyboard.press("Tab");
    const contained = await page.evaluate(() => !!document.activeElement?.closest("#menu-movil") || document.activeElement?.getAttribute("aria-controls") === "menu-movil");
    expect(contained).toBe(true);
  }
  await page.keyboard.press("Escape");
  await expect(open).toBeFocused();
  await page.locator('footer a[href="#/privacidad"]').click();
  await expect(page.locator("h1")).toContainText("données personnelles");
  await expect(page.getByText("Document provisoire — en attente de révision juridique", { exact: true })).toBeVisible();
});

test("ASCII reacts to pointer, pauses, and reduced motion is static", async ({ page }) => {
  await page.goto("/#/");
  const pre = page.locator("#top figure pre");
  await expect(pre).not.toBeEmpty();
  const bounds = await pre.boundingBox();
  expect(bounds).toBeTruthy();
  await page.mouse.move(bounds!.x + bounds!.width * 0.4, bounds!.y + bounds!.height * 0.5);
  await page.waitForTimeout(150);
  const animated = await pre.textContent();
  await page.mouse.move(bounds!.x + bounds!.width * 0.7, bounds!.y + bounds!.height * 0.6);
  await page.waitForTimeout(150);
  expect(await pre.textContent()).not.toBe(animated);
  await page.locator("#top").getByRole("button", { name: "Pausar animación" }).click();
  const paused = await pre.textContent();
  await page.waitForTimeout(250);
  expect(await pre.textContent()).toBe(paused);
  await page.emulateMedia({ reducedMotion: "reduce" });
  await expect(page.locator(".iter-cursor")).toHaveCount(0);
  await page.waitForTimeout(100);
  const staticFrame = await pre.textContent();
  await page.waitForTimeout(250);
  expect(await pre.textContent()).toBe(staticFrame);
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.goto("/#/contacto");
  const background = page.locator("#contacto pre");
  const initial = await background.textContent();
  await page.mouse.move(600, 400);
  await page.waitForTimeout(180);
  expect(await background.textContent()).not.toBe(initial);
});
